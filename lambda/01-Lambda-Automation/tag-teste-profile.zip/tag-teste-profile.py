import boto3

def tag_ec2_instances(session, account_id):
    ec2 = session.client('ec2')
    response = ec2.describe_instances()
    instances = []
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            # Filtra instâncias pelo nome iniciado com "node_group"
            if 'Tags' in instance:
                # Verifica se a instância tem uma tag de Name que começa com "node_group"
                if not any(tag['Key'] == 'Name' and tag['Value'].startswith('node_group') for tag in instance['Tags']):
                    instances.append(instance['InstanceId'])
            else:
                # Inclui instâncias sem tag Name
                instances.append(instance['InstanceId'])
    if instances:
        ec2.create_tags(
            Resources=instances,
            Tags=[
                {
                    'Key': 'Instance-Scheduler',
                    'Value': '2'
                },
            ]
        )
    print(f"Tagged {len(instances)} EC2 instances.")


def tag_rds_instances(session,account_id):
    rds = session.client('rds')
    response = rds.describe_db_instances()
    dbs = [db['DBInstanceIdentifier'] for db in response['DBInstances']]
    for db in dbs:
        rds.add_tags_to_resource(
            ResourceName=f"arn:aws:rds:{session.region_name}:{account_id}:db:{db}",
            Tags=[
                {
                    'Key': 'Instance-Scheduler',
                    'Value': '2'
                },
            ]
        )
    print(f"Tagged {len(dbs)} RDS instances.")

# def tag_all_resources(profile_name='producao', region_name='us-east-1'):
#    session = create_session(profile_name, region_name)
def tag_all_resources():
    session = create_session()
    # Cria um cliente STS usando a sessão
    sts = session.client('sts')
    # Chama o método get_caller_identity para obter detalhes sobre a entidade
    identity = sts.get_caller_identity()
    # Retorna o Account ID
    account_id = identity['Account']
    tag_ec2_instances(session,account_id)
    tag_rds_instances(session,account_id)

# def create_session(profile_name='producao', region_name='us-east-1'):
#     session = boto3.session.Session(profile_name=profile_name, region_name=region_name)
def create_session():
    # Cria uma sessão usando um perfil específico
    session = boto3.session.Session()
    return session

def main():
    # Substitua 'producao' pelo nome do seu perfil, ou remova o parâmetro se não estiver usando perfis
#    tag_all_resources('lab01', 'sa-east-1')
    tag_all_resources()

if __name__ == "__main__":
    main()
    # account_id = get_account_id('producao')
    # print(f"Account ID: {account_id}")
    # Chame esta função para aplicar as tags usando o perfil "producao"
