import boto3
import psycopg2
import os

def lambda_handler(event, context):
    ec2_client = boto3.client('ec2', region_name='sa-east-1')
    ssm = boto3.client('ssm', region_name='sa-east-1')
    
    # Listar instâncias ativas
    response = ec2_client.describe_instances(
        Filters=[{'Name': 'instance-state-name', 'Values': ['running']}]
    )
    
    instance_ids = [instance['InstanceId'] for reservation in response['Reservations'] for instance in reservation['Instances']]
    
    for instance_id in instance_ids:
        response = ssm.send_command(
            DocumentName='ColetarMetricas',
            Targets=[{'Key': 'instanceIds', 'Values': [instance_id]}],
            TimeoutSeconds=600,
            MaxConcurrency='50',
            MaxErrors='0'
        )
        command_id = response['Command']['CommandId']

        # Aguarde a conclusão do comando
        waiter = ssm.get_waiter('command_executed')
        waiter.wait(CommandId=command_id, InstanceId=instance_id)

        # Obtenha os resultados
        response = ssm.list_command_invocations(
            CommandId=command_id,
            InstanceId=instance_id,
            Details=True
        )
        output = response['CommandInvocations'][0]['CommandPlugins'][0]['Output']
        linhas = output.split('\n')
        cpu_usage = linhas[1]
        mem_usage = linhas[3]
        disk_usage = linhas[5]

        # Armazene os resultados no banco de dados PostgreSQL
        connection = psycopg2.connect(
            host=os.environ['DB_HOST'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASSWORD'],
            dbname=os.environ['DB_NAME']
        )
        cursor = connection.cursor()
        sql = "INSERT INTO metricas (instance_id, cpu_usage, mem_usage, disk_usage) VALUES (%s, %s, %s, %s)"
        cursor.execute(sql, (instance_id, cpu_usage, mem_usage, disk_usage))
        connection.commit()
        cursor.close()
        connection.close()

    return {
        'statusCode': 200,
        'body': 'Métricas coletadas e armazenadas com sucesso!'
    }